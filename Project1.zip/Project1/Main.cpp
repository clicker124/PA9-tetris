////#include "PA9.h"
//#include <SFML/Graphics.hpp>
//#include <iostream>
//using namespace std;
//using namespace sf;
//
//int block[7][4][4] =
//{
//	1,0,0,0,
//	1,0,0,0,
//	1,0,0,0,
//	1,0,0,0,
//
//	1,0,0,0,
//	1,1,0,0,
//	0,1,0,0,
//	0,0,0,0,
//
//	0,1,0,0,
//	1,1,0,0,
//	1,0,0,0,
//	0,0,0,0,
//
//	1,1,0,0,
//	1,1,0,0,
//	0,0,0,0,
//	0,0,0,0,
//
//	1,0,0,0,
//	1,1,0,0,
//	1,0,0,0,
//	0,0,0,0,
//
//	1,0,0,0,
//	1,0,0,0,
//	1,1,0,0,
//	0,0,0,0,
//
//	0,1,0,0,
//	0,1,0,0,
//	1,1,0,0,
//	0,0,0,0,
//};
//
//const Color color_map[] = {
//	Color::Green, Color::Blue, Color::Red, Color::Yellow,
//	Color::White, Color::Magenta, Color::Cyan
//};
//
//const int cell_size = 40;
//
////width of screen
//const int width_count = 10;
////height of screen
//const int height_count = 20;
////the field inside of the screen
//int field[height_count][width_count] = { 0 };
//
//
//int main(void)
//{
//	int score = -5;
//
//
//	int blockType; // block blockType
//	int curx; // current x position of block
//	int cury; //current y posistion of the block
//
//	//create the window
//	RenderWindow window(VideoMode(width_count * cell_size, height_count * cell_size), "Tetris");
//	
//	RectangleShape cell(Vector2f(cell_size, cell_size));
//
//	auto new_block = [&]()
//	{
//		score += 5;
//		blockType = rand() % 7, curx = width_count / 2, cury = -4;
//		//cout << score;
//	};
//	new_block();
//
//	auto check_block = [&]()
//	{
//
//		for (int y = 0; y < 4; y++)
//			for (int x = 0; x < 4; x++)
//			{
//				if (block[blockType][y][x] == 0)
//					continue;
//				if (x + curx < 0 || x + curx >= width_count ||  y + cury >= height_count)
//				{
//					return false; // hit wall
//				}
//				//if you hit a field block, aka any block already placed
//				//the if statement is specifically, if there is something other than null at this spot
//				if (field[cury + y][curx + x])
//				{
//					cout << field[cury + y][curx + x];
//					//check that the block does not go above the window
//					//pseudo code - if the blocks go less that 0, they are above the window and you lose.
//					if (cury < 0)
//					{
//						window.close();
//						cout << "Score: " << score;
//					}
//
//					return false; // collision with field blocks
//				}
//			}
//		return true;
//	};
//
//	//clear the lines that have been completed and move everything else down 1
//	auto clear_lines = [&]()
//	{
//		
//		int to = height_count - 1;
//		//from bottom line to top line...
//		for (int from = height_count - 1; from >= 0; from--)
//		{
//			int cnt = 0;
//			for (int x = 0; x < width_count; x++)
//				if (field[from][x])
//					cnt++;
//
//			//if current line is not full, copy it(survived line)
//			if (cnt < width_count)
//			{
//				for (int x = 0; x < width_count; x++)
//					field[to][x] = field[from][x];
//				to--;
//			}
//			//otherwise it will be deleted(clear the line)
//		}
//	};
//
//	auto go_down = [&]()
//	{
//		//send the block down one
//		cury++;
//		if (check_block() == false) // check if hit bottom
//		{
//			//keep the block at that spot
//			cury--;
//			//for every instance of the type of block
//			for (int y = 0; y < 4; y++)
//				for (int x = 0; x < 4; x++)
//					//check until we are on the same type of block as the current in game one
//					if (block[blockType][y][x])
//					{
//						//when we are on that block set that portion of the field equal to whatever block is there
//						field[cury + y][curx + x] = blockType + 1 ;//+1 for avoiding 0
//						//cout << "wow";
//					}
//			clear_lines();
//			//start next block
//			
//
//			new_block();
//			return false;
//		}
//		return true;
//	};
//
//	auto rotate = [&]()
//	{
//		int len = 0; // check rotation block size
//		for (int y = 0; y < 4; y++)for (int x = 0; x < 4; x++)
//			if (block[blockType][y][x]) len = max(max(x, y) + 1, len);
//
//		int d[4][4] = { 0 };
//		//rotate conter-clock wise 90 degree
//		for (int y = 0; y < len; y++)for (int x = 0; x < len; x++)
//			if (block[blockType][y][x]) d[len - 1 - x][y] = 1;
//		for (int y = 0; y < 4; y++)for (int x = 0; x < 4; x++)
//			block[blockType][y][x] = d[y][x];
//	};
//
//	Clock clock;
//	while (window.isOpen())
//	{
//		//set the clock as seconds and check the clock for every 0.5 seconds
//		static float prev = clock.getElapsedTime().asSeconds();
//		if (clock.getElapsedTime().asSeconds() - prev >= 0.5)
//		{
//			//if the clock exceeds 0.5 seconds then reset it and move the block down. 
//			prev = clock.getElapsedTime().asSeconds();
//			go_down();
//		}
//
//		Event e;
//		while (window.pollEvent(e))
//		{
//			//if you close the window, close the window
//			if (e.type == Event::Closed)
//			{
//				cout << "Score: " << score;
//				window.close();
//			}
//
//			//if a key is pressed
//			if (e.type == Event::KeyPressed)
//			{
//				if (e.key.code == Keyboard::Left)
//				{
//					curx--;
//					if (check_block() == false) curx++;
//				}
//				else if (e.key.code == Keyboard::Right)
//				{
//					curx++;
//					if (check_block() == false) curx--;
//				}
//				else if (e.key.code == Keyboard::Down)
//				{
//					go_down();
//				}
//				else if (e.key.code == Keyboard::Up)
//				{
//					rotate();
//					if (check_block() == false) { rotate(), rotate(), rotate(); }
//				}
//				else if (e.key.code == Keyboard::Space)
//				{
//					while (go_down() == true);
//				}
//			}
//		}
//		window.clear();
//
//		auto draw_field = [&]()
//		{
//			for (int y = 0; y < height_count; y++)
//				for (int x = 0; x < width_count; x++)
//					if (field[y][x])
//					{
//						cell.setFillColor(color_map [field[y][x] - 1]);
//						cell.setPosition(Vector2f(x * cell_size, y * cell_size));
//						window.draw(cell);
//					}
//		};
//		draw_field();
//
//		 //define c++11 lambda function
//		 //this function can use all the "outside" variables like blockType, curx, cury!
//		auto draw_block = [&]()
//		{
//			cell.setFillColor(color_map[blockType]);
//			for (int y = 0; y < 4; y++)for (int x = 0; x < 4; x++)
//				if (block[blockType][y][x])
//				{
//					cell.setPosition(Vector2f((curx + x) * cell_size, (cury + y) * cell_size));
//					window.draw(cell);
//				}
//		};
//		//call the lambda function above
//		draw_block();
//
//		window.display();
//	}
//	return 0;
//}

#include "PA9.h"

int main()
{
	Tetris game;
	return 0;
}