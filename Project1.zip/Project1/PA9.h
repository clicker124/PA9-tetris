#ifndef PA9
#define PA9
#include <SFML/Graphics.hpp>
#include <iostream>
using namespace std;
using namespace sf;




class Tetris
{
private:
	
	

public:
	
	Tetris();

	void new_block(int score, int blockType, int curx, int cury, int width_count);

	bool check_block(RenderWindow& window, int block[][4][4], int blockType, int curx, int cury, int width_count, int height_count, int field[][10], int score);

	void clear_lines(int height_count, int width_count, int field[][10]);

	bool go_down(RenderWindow& window, int curx, int cury, int block[][4][4], int blockType, int field[][10], int width_count, int height_count, int score);

	void rotate(int block[][4][4], int blockType);

	void draw_field(RectangleShape cell, RenderWindow& window, int height_count, int width_count, int field[][10], int cell_size, Color color_map[]);

	void draw_block(RectangleShape cell, RenderWindow& window, Color color_map[], int blockType, int block[][4][4], int curx, int cury, int cell_size);

};




#endif